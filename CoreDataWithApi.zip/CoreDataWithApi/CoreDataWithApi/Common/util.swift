//
//  util.swift
//  Flexyn
//
//  Created by day on 07/11/17.
//  Copyright © 2017 day. All rights reserved.
//

import Foundation


let Common_Domain = "http://tarkeebc.ampro5.fcomet.com/index.php/?route=api/wkrestapi/catalog/getProduct"


