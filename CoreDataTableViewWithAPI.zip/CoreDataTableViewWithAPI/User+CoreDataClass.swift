//
//  User+CoreDataClass.swift
//  CoreDataTableViewWithAPI
//
//  Created by Jony on 22/08/20.
//  Copyright © 2020 Jony. All rights reserved.
//
//

import Foundation
import CoreData

@objc(User)
public class User: NSManagedObject {

}
