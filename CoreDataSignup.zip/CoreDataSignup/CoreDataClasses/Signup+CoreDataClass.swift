//
//  Signup+CoreDataClass.swift
//  CoreDataSignup
//
//  Created by Jony on 29/07/20.
//  Copyright © 2020 Jony. All rights reserved.
//
//

import Foundation
import CoreData


public class Signup: NSManagedObject {

}
